package chatserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class ChatServer{
	public static ServerSocket ss;
	public  Socket ssNew;
	
	
	//@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ChatServer cs = new ChatServer();
		try {
			ss = new ServerSocket(5000);
						
		
			while (true){
					
					cs.ssNew = ss.accept();
					ServerThread sT = new ServerThread();  
					sT.ssNew = cs.ssNew;
					System.out.println ("After Accept");
					sT.run_main();		
			}
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}/* End of main() */
}