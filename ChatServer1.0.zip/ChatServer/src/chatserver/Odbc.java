package chatserver;

import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.pool.OracleDataSource;

public class Odbc {
	
	private static final Socket ss = null;
	public static String url="jdbc:oracle:thin:@localhost:1521:xe";
	public static String login,password;
	public static Connection conn;
	
	public static boolean dbCheck(String passwdInfo) throws SQLException{
		
		OracleDataSource ods = new OracleDataSource();
		ods.setURL(url);
		ods.setUser("wm910");
		ods.setPassword("wm910");
		conn = ods.getConnection();
		boolean valid = false;
		boolean bVar;
		
		
		if (passwdInfo != null){
			String[] s = passwdInfo.split("/");
			login = s[1];
			password = s[2];
			System.out.println("login and password are" + login + password);
		}
		//String sql = "select * from wm98.pwdTable where login = " + login + " and password=" +password + ";";
		String sql = "select * from wm910.pwdTable where login = '" + login + "'";
		System.out.println("The sql is " + sql);
		PreparedStatement ps = conn.prepareStatement(sql);
		bVar = ps.execute();
		System.out.println("The return value from ps.execute is" +bVar);
		if (bVar = true){
			valid =  true;
		}
		return valid;
	}

	public Socket getSocket(String connFrom) {
		// TODO Auto-generated method stub
		String sql = "select ss from wm910.ticket where ConnFrom ='" +  connFrom + "'";
		return ss;		
				
	}

	public boolean insertDB(String connTo, String connFrom, Socket ss) {
		// TODO Auto-generated method stub
		
		try {
			boolean bVar = false;
			String sql = "INSERT INTO wm910.ticket " + "VALUES (" + connFrom + "," + connTo + "," + ss + ")";
			
			System.out.println(sql);
			PreparedStatement ps = conn.prepareStatement(sql);
				
				bVar = ps.execute();
		
				if (bVar = true){
					System.out.println("Record inserted into the db");
				} else {
					System.out.println("Record could not be inserted into the db");
				}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println ("");
		//return bVar;
		return false;
		
	}

	public String getReceivers() {
		// TODO Auto-generated method stub
		String recvrlist = null;
		String sql = "Select ConnFrom from wm910.Ticket";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			String recvrs[] = null;
			int i=0;
			while (rs.next()){
				recvrs[i++] = rs.getString("ConnFrom");
			}
			recvrlist = recvrs.toString();
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return recvrlist;
	}

	public String getSenders(String connFrom) {
		// TODO Auto-generated method stub
		
		String senders[] = null,senderslist = null;
		String sql = "select ConnFrom wm910.ticket";
		Statement s;
		try {
			s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
		
			int i = 0;
			while (rs.next()){
				senders[i++] = rs.getString("ConnFrom");
			}
			senderslist = senders.toString();
			senderslist = senderslist.replace(connFrom, " ");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return senderslist;
	}
}