package chatserver;

import java.net.*;

public class UserTicket {
		
		String ipStr;
		String ConnFrom;
		String ConnTo;
		Socket ssNew;
		
	}
