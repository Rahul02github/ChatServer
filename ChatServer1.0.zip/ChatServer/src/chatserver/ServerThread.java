package chatserver;

import java.net.*;
import java.sql.SQLException;
import java.io.*;

//public class ServerThread extends Thread {
public class ServerThread{
	public static Socket ssNew;
	public static boolean recAvailable;
	public static Odbc odbc;

	//public void run() {
	public static void run_main(){

		odbc = new Odbc();
		try {
			UserTicket ut = new UserTicket();
			ut.ssNew = ssNew;
			//while (true) {

				DataInputStream dis = new DataInputStream(
						ut.ssNew.getInputStream());
				DataOutputStream dos = new DataOutputStream(
						ut.ssNew.getOutputStream());

				ut.ipStr = dis.readUTF();
				System.out.println("String is " + ut.ipStr);

				if (ut.ipStr.equals("exit")) {
					ut.ssNew.close();
					dos.close();
					dis.close();
					//break;
				} else if (ut.ipStr.startsWith("refresh/")) {
					String users = odbc.getSenders(ut.ConnFrom);
					String userlist = "refresh/" + users;
					dos.writeUTF(userlist);
				} else if (ut.ipStr.startsWith("Validate/")) {
					System.out.println("I am in validate password");
					System.out.println("ipstr is " + ut.ipStr);
					boolean recAvailable = odbc.dbCheck(ut.ipStr);
					if (recAvailable = false) {
						dos.writeUTF("Member Not Found");
					} else {
						dos.writeUTF("Member Found");
						System.out.println("Valid member");
						ut.ConnFrom = parseUser(ut.ipStr);
						System.out.println(ut.ConnFrom + ut.ssNew);
						boolean insertRec = odbc.insertDB(ut.ConnFrom, null,
								ut.ssNew);
						if (insertRec = false) {
							System.out.println("Error inserting record");
						} else {
							System.out.println("Inserted the record");
						}
					}
					ut.ipStr = null;
					//continue;
				} else if (ut.ipStr.startsWith("Chat/")) {
					ut.ConnTo = parseRecvr(ut.ipStr);
					ConnToInfo cti = new ConnToInfo();
					cti.s = odbc.getSocket(ut.ConnTo);

					while (true) {
						cti.disTo = new DataInputStream(cti.s.getInputStream());
						cti.dosTo = new DataOutputStream(
								cti.s.getOutputStream());

						cti.ipStrTo = cti.disTo.readUTF();
						System.out.println("String is " + cti.ipStrTo);

						if (cti.ipStrTo.equals("exit")) {
							cti.s.close();
							cti.dosTo.close();
							cti.disTo.close();
							break;
						} else {
							cti.dosTo.writeUTF("Hello world \n");
							cti.ipStrTo = null;
							continue;
						}
					}/* End of while() */
				}/* End of if-else */
			//}/* End of while() */
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}/* End of try-catch */
	}/* End of run() */

	private static String parseRecvr(String ipStr) {
		// TODO Auto-generated method stub
		String[] s1 = ipStr.split("/");

		return s1[1];
	}

	private static String parseUser(String ipStr) {
		// TODO Auto-generated method stub
		String[] s1 = ipStr.split("/");
		System.out.println(s1[1]);

		return s1[1];
	}
}
