package chatserverclient;

public class RefreshUsers extends Thread{

	public static DoNil dn;
	
	public RefreshUsers(DoNil dn2) {
		// TODO Auto-generated constructor stub
		dn = dn2;
	}

	//public static RefreshUsers ru = new RefreshUsers();
	public void run() {
		// TODO Auto-generated method stub
	
		try {
			
			while(true){
				this.sleep(1000);
				dn.notify();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

}
