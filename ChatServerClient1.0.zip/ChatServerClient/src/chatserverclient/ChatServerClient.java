package chatserverclient;
import java.io.*;
import java.lang.*;
import java.net.*;

public class ChatServerClient {
	public static ClientThread cT;
	public static RefreshUsers ru;
	public static DoNil dn;
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		cT = new ClientThread();	
		cT.run_main();
		
		
		//dn =new DoNil("donil");
		//cT = new ClientThread(dn);	
		//ru = new RefreshUsers(dn);
		
		//ru.start();
		//cT.start();
		/* try {
			cT.refresh();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		*/		
	}
}	
