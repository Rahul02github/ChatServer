package chatserverclient;
import java.io.*;
import java.lang.*;
import java.net.*;

//public class ClientThread extends Thread{
public class ClientThread{
		private static Socket s;
		private static String sendStr;
		public static UIInit ui;
		public static UIHomeInit uih;
		public static DataInputStream dis;
		public static DataOutputStream dos;
		public static CSClientListener cscl;
		public static CSClientHListener cschl;
		public static String users[];
		public static String ConnFrom;
		public static boolean isAwake = false;
		public static boolean isChatting = false;
		public static RefreshUsers ru;
		public static ChatServerClient csc;
		public static DoNil dn;
		public static String serverSays = null;
		/* public ClientThread(DoNil dn2) {
			// TODO Auto-generated constructor stub
			dn = dn2;
		}*/

		//public  void run() {
		public static void run_main(){

			// TODO Auto-generated method stub
			uih = new UIHomeInit();
			ui = new UIInit();
			sendStr = null;
			ClientThread cT =new ClientThread();
					
			createConnection();
			try {
				dis = new DataInputStream(s.getInputStream());
				dos = new DataOutputStream(s.getOutputStream());
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			uih.createHUI();
			/* cT.processPassword();
			cT.processMessages();
			cT.closeConnection();*/
		}
		
		/* public synchronized void refresh() throws InterruptedException {
			// TODO Auto-generated method stub
			
			
			dn.wait();
			sendStr = "refresh/" + ConnFrom;
			processMessages();	
		
	}	*/

		private static void createConnection() {
			
			try {
				s = new Socket("localhost",5000);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Host not accepting connections");
				System.exit(-1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error Opening Connection");
				System.exit(-1);
			}
				
		}

		public void closeConnection() {
			// TODO Auto-generated method stub
			
			try {
				if (s != null){
					s.close();
					System.out.println("Finished closing Connection");
					ui.closeUI();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Could Not Close Connection");
			}
			
		}

		public static void processMessages(){
			if (isAwake == false){
				cscl = new CSClientListener();
			}else {
				cscl.actionPerformed(null);
			}
			while(true){
				System.out.println("in processMessages");
				
				if (isChatting == false){
					sendStr = ui.getMessage();
				}
				System.out.println(sendStr);
				
				try {
					dos.writeUTF(sendStr);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error Writing to Server");
					//System.exit(-1);
				}
				System.out.println("Completed Writing");

				String serverSays = null;
				try {
					serverSays = dis.readUTF();
					if (serverSays.startsWith("refresh/")){
						serverSays = serverSays.split("/")[1];
						users = serverSays.split(" ");
						ui.listUsers(users);
					}else{
						System.out.println("Completed Reading");
						System.out.println ("The response from server is:" + serverSays);
						populateMessage(serverSays);
						System.out.println("populating Message is over");
						cscl.actionPerformed(null);
					}
									
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error Reading From Server");
					//System.exit(-1);
				}
				
			}
		}

		private static void populateMessage(String serverSays) {
			// TODO Auto-generated method stub
				ui.tMessage2.append(serverSays); 
				System.out.println("Program is here");
		}

		
		public void processPassword(){
			// TODO Auto-generated method stub
			
			cschl = new CSClientHListener();
			
				

				System.out.println("in processPassword");						
				sendStr = uih.getPassword();			
				System.out.println(sendStr);
				try {
					dos.writeUTF(sendStr);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error Writing to Server");
					//System.exit(-1);
				}
				System.out.println("Completed Writing");

				
				try {
					serverSays = dis.readUTF();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error Reading From Server");
					//System.exit(-1);
				}
				if (serverSays.equals("Member Not Found")){
					uih.writeStatus("Member Not Found");				
					cschl.actionPerformed(null);
					
				}else if(serverSays.equals("Member Found")){
					System.out.println("Member Found - Starting Chat UI");
					uih.closeUIH();
					ui.createUI();
					cscl.actionPerformed(null);
					System.out.println("Created Chat UI");
				}
			
	    }

		public void connectToUser(String user) {
			// TODO Auto-generated method stub
			String serverSays;
			
			sendStr = "Chat/" + user;
			isChatting = true;
			isAwake = true;
			processMessages();	
		}

}
